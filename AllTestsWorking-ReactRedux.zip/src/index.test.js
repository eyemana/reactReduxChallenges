import { expect } from "chai";

it("should pass", () => {
  expect(true).to.equal(true);
});
